package net.xclient.modules.optimization;

import net.xclient.core.event.SubscribeEvent;
import net.xclient.core.event.events.TickEvent;
import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Tracks idle time (no keyboard/mouse input, window unfocused) and lowers
 * the effective FPS cap during idle periods to save battery/thermals on
 * mobile devices, restoring the user's normal cap the instant input resumes.
 */
public class DynamicFPS extends Module {

    private final SliderSetting idleFps = register(new SliderSetting("Idle FPS Cap", 30, 5, 60, 5, true));
    private final SliderSetting idleDelaySeconds = register(new SliderSetting("Idle Delay (s)", 20, 5, 120, 5, true));

    private int normalFpsCap;
    private long idleSinceMs = System.currentTimeMillis();

    public DynamicFPS() {
        super("Dynamic FPS", "Lowers the FPS cap while idle or unfocused to save battery/heat.",
                ModuleCategory.OPTIMIZATION, true);
    }

    @Override
    protected void onEnable() {
        normalFpsCap = mc.options.getMaxFps().getValue();
    }

    @Override
    protected void onDisable() {
        mc.options.getMaxFps().setValue(normalFpsCap);
    }

    @SubscribeEvent
    public void onTick(TickEvent event) {
        if (event.getPhase() != TickEvent.Phase.END) return;

        boolean unfocused = !mc.isWindowFocused();
        boolean idleLongEnough = (System.currentTimeMillis() - idleSinceMs) / 1000.0 > idleDelaySeconds.getValue();

        if (unfocused || idleLongEnough) {
            mc.options.getMaxFps().setValue(idleFps.getValue().intValue());
        } else {
            mc.options.getMaxFps().setValue(normalFpsCap);
        }
    }

    /** Called by the mixin hook on any keyboard/mouse activity to reset the idle timer. */
    public void notifyActivity() {
        idleSinceMs = System.currentTimeMillis();
    }
}
