package net.xclient.gui.clickgui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.xclient.core.module.Module;
import net.xclient.core.settings.*;
import net.xclient.gui.theme.XTheme;
import net.xclient.util.RenderUtil;

/**
 * Floating panel listing every {@link Setting} a module exposes. Rendered
 * beside the clicked card; each setting type gets its own compact widget so
 * the whole panel stays readable even with 5-6 settings stacked.
 */
public final class ModuleSettingsPanel {

    private static final int PANEL_WIDTH = 180;
    private static final int ROW_HEIGHT = 22;

    private ModuleSettingsPanel() {}

    public static void render(DrawContext ctx, Module module, int mouseX, int mouseY) {
        var mc = MinecraftClient.getInstance();
        var settings = module.getSettings().stream().filter(Setting::isVisible).toList();

        int panelHeight = 20 + settings.size() * ROW_HEIGHT;
        int x = Math.min(mc.getWindow().getScaledWidth() - PANEL_WIDTH - 8, mouseX + 12);
        int y = Math.min(mc.getWindow().getScaledHeight() - panelHeight - 8, mouseY);

        RenderUtil.card(ctx, x, y, PANEL_WIDTH, panelHeight, false);
        ctx.drawText(mc.textRenderer, module.getName(), x + 8, y + 6, XTheme.ACCENT, true);

        int rowY = y + 20;
        for (Setting<?> setting : settings) {
            renderSetting(ctx, setting, x + 8, rowY, PANEL_WIDTH - 16);
            rowY += ROW_HEIGHT;
        }
    }

    private static void renderSetting(DrawContext ctx, Setting<?> setting, int x, int y, int width) {
        var mc = MinecraftClient.getInstance();

        ctx.drawText(mc.textRenderer, setting.getName(), x, y, XTheme.TEXT_SECONDARY, false);

        if (setting instanceof BooleanSetting b) {
            int pillW = 26, pillH = 12;
            int pillX = x + width - pillW;
            int color = b.getValue() ? XTheme.TOGGLE_ON : XTheme.TOGGLE_OFF;
            RenderUtil.roundedRect(ctx, pillX, y - 1, pillW, pillH, pillH / 2, color);
            int knobX = pillX + (b.getValue() ? pillW - pillH + 2 : 2);
            RenderUtil.roundedRect(ctx, knobX, y, pillH - 4, pillH - 4, (pillH - 4) / 2, 0xFFFFFFFF);

        } else if (setting instanceof SliderSetting s) {
            int barY = y + 11;
            RenderUtil.roundedRect(ctx, x, barY, width, 3, 1, XTheme.TOGGLE_OFF);
            int filled = (int) (width * s.getRatio());
            RenderUtil.roundedRect(ctx, x, barY, Math.max(3, filled), 3, 1, XTheme.ACCENT);
            String valueText = s.isInteger() ? String.valueOf(s.getValue().intValue()) : String.format("%.2f", s.getValue());
            ctx.drawText(mc.textRenderer, valueText, x + width - mc.textRenderer.getWidth(valueText), y, XTheme.TEXT_PRIMARY, false);

        } else if (setting instanceof ModeSetting m) {
            String value = m.getValue();
            ctx.drawText(mc.textRenderer, value, x + width - mc.textRenderer.getWidth(value), y, XTheme.ACCENT, false);

        } else if (setting instanceof ColorSetting c) {
            int swatchSize = 12;
            ctx.fill(x + width - swatchSize, y - 1, x + width, y - 1 + swatchSize, c.getValue());
        }
    }

    /**
     * Click routing for settings widgets. Called from a screen's mouseClicked
     * once it determines the click landed within the panel bounds returned by
     * the last {@link #render} call (bounds tracking omitted here for brevity -
     * see README for the full hit-test implementation pattern).
     */
    public static void handleSliderDrag(SliderSetting setting, double mouseX, double panelX, int width) {
        double ratio = (mouseX - panelX) / width;
        setting.setFromRatio(ratio);
    }
}
