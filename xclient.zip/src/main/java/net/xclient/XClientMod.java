package net.xclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.xclient.core.config.ConfigManager;
import net.xclient.core.event.EventBus;
import net.xclient.core.event.events.RenderEvent;
import net.xclient.core.event.events.TickEvent;
import net.xclient.core.keybind.KeybindManager;
import net.xclient.core.module.ModuleManager;
import net.xclient.core.notification.NotificationManager;
import net.xclient.gui.clickgui.ClickGUIScreen;
import org.lwjgl.glfw.GLFW;

/**
 * Client entrypoint. Responsible only for:
 *  1. Building the module registry and config manager.
 *  2. Bridging Fabric API's native callbacks into our own {@link EventBus},
 *     so every module only ever has to know about {@code TickEvent} /
 *     {@code RenderEvent} / etc, not Fabric API directly.
 *  3. Registering the ClickGUI open keybind.
 */
public class XClientMod implements ClientModInitializer {

    public static final String MOD_ID = "x-client";

    private static ModuleManager moduleManager;
    private static ConfigManager configManager;
    private static KeybindManager keybindManager;

    /** GLFW key that opens the ClickGUI - Right Shift by default, matches Feather Client's convention. */
    private static int clickGuiKey = GLFW.GLFW_KEY_RIGHT_SHIFT;

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        configManager = new ConfigManager();
        keybindManager = new KeybindManager(moduleManager);

        moduleManager.registerAll();
        EventBus.INSTANCE.subscribe(keybindManager);
        EventBus.INSTANCE.subscribe(new net.xclient.gui.hud.ToastRenderer());
        configManager.load(moduleManager);

        registerTickBridge();
        registerRenderBridge();
        registerLifecycleBridge();
        registerGuiKeybind();

        NotificationManager.INSTANCE.push("X Client", "Loaded successfully.",
                net.xclient.core.notification.NotificationType.SUCCESS);
    }

    private void registerTickBridge() {
        ClientTickEvents.START_CLIENT_TICK.register(client ->
                EventBus.INSTANCE.post(new TickEvent(TickEvent.Phase.START)));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EventBus.INSTANCE.post(new TickEvent(TickEvent.Phase.END));
            NotificationManager.INSTANCE.tick();
        });
    }

    private void registerRenderBridge() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
                EventBus.INSTANCE.post(new RenderEvent(RenderEvent.Type.HUD_2D, drawContext, tickDelta.getTickDelta(true))));

        // NOTE: A WORLD_3D bridge previously lived here, wired to
        // net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents#AFTER_TRANSLUCENT.
        // That flat package/class no longer exists in current Fabric API - it was removed
        // during Minecraft's rendering-pipeline rewrite and only reintroduced starting with
        // Fabric API for Minecraft 1.21.10, under a NEW package:
        //   net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents
        //   net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext
        // Referencing the old (nonexistent) class is exactly what threw the
        // NoClassDefFoundError/ClassNotFoundException that crashed the client on init.
        // No module currently subscribes to RenderEvent.Type.WORLD_3D, so the bridge was
        // simply dead code and has been removed rather than ported. If you add a module that
        // needs to draw in the world later, register against the new WorldRenderEvents class
        // above (see https://docs.fabricmc.net/1.21.11/develop/rendering/world) and post a
        // RenderEvent(RenderEvent.Type.WORLD_3D, ...) from there.
    }

    private void registerLifecycleBridge() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
                NotificationManager.INSTANCE.push("Connected", "Joined the server.",
                        net.xclient.core.notification.NotificationType.INFO));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> configManager.save(moduleManager));
    }

    private void registerGuiKeybind() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.currentScreen != null) return;
            long handle = client.getWindow().getHandle();
            if (GLFW.glfwGetKey(handle, clickGuiKey) == GLFW.GLFW_PRESS) {
                MinecraftClient.getInstance().setScreen(new ClickGUIScreen());
            }
        });
    }

    public static ModuleManager getModuleManager() {
        return moduleManager;
    }

    public static ConfigManager getConfigManager() {
        return configManager;
    }

    public static void setClickGuiKey(int key) {
        clickGuiKey = key;
    }
}
