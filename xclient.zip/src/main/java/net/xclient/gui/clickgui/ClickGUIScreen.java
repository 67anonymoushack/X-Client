package net.xclient.gui.clickgui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.xclient.XClientMod;
import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.gui.theme.XTheme;
import net.xclient.modules.hud.ChatTimestamps;
import net.xclient.modules.misc.AutoReply;
import net.xclient.modules.misc.ChatFilter;
import net.xclient.modules.misc.FriendSystem;
import net.xclient.modules.misc.IgnoreList;
import net.xclient.modules.misc.MessageLogger;
import net.xclient.modules.misc.AntiAFK;
import net.xclient.modules.utility.AutoGG;
import net.xclient.modules.utility.AutoText;
import net.xclient.util.Easing;
import net.xclient.util.RenderUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * "Mod Menu" style ClickGUI: an icon sidebar on the left for switching pages,
 * a red header banner, filter tabs + search on the Mod Menu page, and a
 * scrollable 3-column grid of icon cards with a toggle pill each.
 * <p>
 * Layout is recomputed from {@link #width}/{@link #height} on every call
 * (render, mouseClicked, mouseScrolled) rather than cached, so there is no
 * risk of visuals and hit-testing ever drifting apart after a resize.
 */
public class ClickGUIScreen extends Screen {

    // ---- sidebar pages ----
    private enum Page {
        MOD_MENU, GENERAL, CHAT, COSMETIC, GRAPHICS, SOCIAL
    }

    // ---- filter tabs (Mod Menu page only) ----
    private enum Tab {
        ALL, NEW, HUD, HYPIXEL, PVP
    }

    // Modules that don't cleanly belong to one ModuleCategory get an explicit
    // class list per sidebar page instead (kept small and local to this screen -
    // see ModuleMeta for the icon/tag side of the same "extra metadata" idea).
    private static final Set<Class<? extends Module>> GENERAL_EXTRA = Set.of(AntiAFK.class);
    private static final Set<Class<? extends Module>> CHAT_MODULES = Set.of(
            ChatFilter.class, MessageLogger.class, AutoReply.class, AutoText.class, ChatTimestamps.class);
    private static final Set<Class<? extends Module>> SOCIAL_MODULES = Set.of(
            FriendSystem.class, IgnoreList.class, AutoGG.class);

    private static final int SIDEBAR_W = 44;
    private static final int PANEL_GAP = 8;
    private static final int HEADER_H = 32;
    private static final int TAB_ROW_H = 26;
    private static final int GRID_PAD = 10;
    private static final int CARD_GAP = 8;
    private static final int CARD_H = 84;
    private static final int CARD_COLS = 3;
    private static final int TOGGLE_ANIM_MS = 180;

    private static final Identifier ICON_LOGO = id("logo");
    private static final Identifier ICON_MODMENU = id("modmenu");
    private static final Identifier ICON_MODMENU_ACTIVE = id("modmenu1");
    private static final Identifier ICON_GENERAL = id("settings");
    private static final Identifier ICON_GENERAL_ACTIVE = id("settings1");
    private static final Identifier ICON_CHAT = id("chat");
    private static final Identifier ICON_CHAT_ACTIVE = id("chat1");
    private static final Identifier ICON_COSMETIC = id("cosmetics");
    private static final Identifier ICON_COSMETIC_ACTIVE = id("cosmetics1");
    private static final Identifier ICON_GRAPHICS = id("display");
    private static final Identifier ICON_GRAPHICS_ACTIVE = id("display1");
    private static final Identifier ICON_SOCIAL = id("link");
    private static final Identifier ICON_SOCIAL_ACTIVE = id("link1");

    private static Identifier id(String name) {
        return Identifier.of("xclient", "textures/icons/" + name + ".png");
    }

    private long openedAt;
    private Page page = Page.MOD_MENU;
    private Tab tab = Tab.ALL;
    private String searchQuery = "";
    private boolean searchFocused = false;
    private double scrollOffset = 0;
    private Module expandedSettingsModule;
    private final Set<Module> favorites = new HashSet<>();

    public ClickGUIScreen() {
        super(Text.literal("X Client"));
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        RenderUtil.blurBackdrop(ctx, width, height);

        float openProgress = (float) Easing.easeOutBack(Math.min(1.0, (System.currentTimeMillis() - openedAt) / 220.0));
        int slide = (int) (14 * (1 - openProgress));

        int totalW = Math.min(width - 40, 700);
        int totalH = Math.min(height - 40, 420);
        int startX = (width - totalW) / 2;
        int startY = (height - totalH) / 2 + slide;
        int mainX = startX + SIDEBAR_W + PANEL_GAP;
        int mainW = totalW - SIDEBAR_W - PANEL_GAP;

        renderSidebar(ctx, startX, startY, totalH, mouseX, mouseY);

        RenderUtil.dropShadow(ctx, mainX, startY, mainW, totalH, 10);
        RenderUtil.roundedRect(ctx, mainX, startY, mainW, totalH, 10, XTheme.PANEL_BG);

        // header banner (rounded top corners only, flush into the panel body below)
        RenderUtil.roundedRect(ctx, mainX, startY, mainW, HEADER_H, 10, XTheme.ACCENT);
        ctx.fill(mainX, startY + HEADER_H / 2, mainX + mainW, startY + HEADER_H, XTheme.ACCENT);
        ctx.drawText(textRenderer, pageTitle(), mainX + 14, startY + (HEADER_H - 8) / 2, 0xFFFFFFFF, true);

        int gridTop = startY + HEADER_H;

        if (page == Page.MOD_MENU) {
            renderTabRow(ctx, mainX, gridTop, mainW, mouseX, mouseY);
            gridTop += TAB_ROW_H;
        }

        List<Module> visible = visibleModules();
        int gridBottom = startY + totalH - GRID_PAD;
        renderGrid(ctx, visible, mainX + GRID_PAD, gridTop + GRID_PAD / 2, mainW - GRID_PAD * 2,
                gridBottom, mouseX, mouseY);

        if (expandedSettingsModule != null) {
            ModuleSettingsPanel.render(ctx, expandedSettingsModule, mouseX, mouseY);
        }
    }

    private String pageTitle() {
        return switch (page) {
            case MOD_MENU -> "Mod Menu";
            case GENERAL -> "General";
            case CHAT -> "Chat Options";
            case COSMETIC -> "Cosmetic";
            case GRAPHICS -> "Graphics";
            case SOCIAL -> "Social";
        };
    }

    private void renderSidebar(DrawContext ctx, int x, int y, int h, int mouseX, int mouseY) {
        RenderUtil.dropShadow(ctx, x, y, SIDEBAR_W, h, 10);
        RenderUtil.roundedRect(ctx, x, y, SIDEBAR_W, h, 10, XTheme.PANEL_BG);

        int cx = x + SIDEBAR_W / 2;
        int cursorY = y + 12;

        RenderUtil.drawIcon(ctx, ICON_LOGO, cx - 12, cursorY, 24);
        cursorY += 24 + 8;
        ctx.fill(x + 8, cursorY, x + SIDEBAR_W - 8, cursorY + 1, XTheme.TEXT_DISABLED);
        cursorY += 10;

        for (Page p : Page.values()) {
            boolean active = p == page;
            boolean hovered = mouseX >= x && mouseX <= x + SIDEBAR_W && mouseY >= cursorY && mouseY <= cursorY + 32;

            if (active) {
                RenderUtil.roundedRect(ctx, x + 6, cursorY, SIDEBAR_W - 12, 32, 8, XTheme.ACCENT);
            } else if (hovered) {
                RenderUtil.roundedRect(ctx, x + 6, cursorY, SIDEBAR_W - 12, 32, 8, XTheme.CARD_HOVER);
            }

            Identifier icon = sidebarIcon(p, active);
            RenderUtil.drawIcon(ctx, icon, cx - 10, cursorY + 6, 20);

            cursorY += 32 + 8;
        }
    }

    private Identifier sidebarIcon(Page p, boolean active) {
        return switch (p) {
            case MOD_MENU -> active ? ICON_MODMENU_ACTIVE : ICON_MODMENU;
            case GENERAL -> active ? ICON_GENERAL_ACTIVE : ICON_GENERAL;
            case CHAT -> active ? ICON_CHAT_ACTIVE : ICON_CHAT;
            case COSMETIC -> active ? ICON_COSMETIC_ACTIVE : ICON_COSMETIC;
            case GRAPHICS -> active ? ICON_GRAPHICS_ACTIVE : ICON_GRAPHICS;
            case SOCIAL -> active ? ICON_SOCIAL_ACTIVE : ICON_SOCIAL;
        };
    }

    private void renderTabRow(DrawContext ctx, int mainX, int y, int mainW, int mouseX, int mouseY) {
        int px = mainX + GRID_PAD;
        int py = y + (TAB_ROW_H - 16) / 2;

        for (Tab t : Tab.values()) {
            String label = tabLabel(t);
            int w = textRenderer.getWidth(label) + 14;
            boolean active = t == tab;
            boolean hovered = mouseX >= px && mouseX <= px + w && mouseY >= py && mouseY <= py + 16;

            if (active) {
                RenderUtil.roundedRect(ctx, px, py, w, 16, 8, XTheme.ACCENT);
            } else if (hovered) {
                RenderUtil.roundedRect(ctx, px, py, w, 16, 8, XTheme.CARD_HOVER);
            } else {
                RenderUtil.roundedRect(ctx, px, py, w, 16, 8, XTheme.CARD_BG);
            }
            int textColor = active ? 0xFFFFFFFF : XTheme.TEXT_SECONDARY;
            ctx.drawText(textRenderer, label, px + (w - textRenderer.getWidth(label)) / 2, py + 4, textColor, false);

            px += w + 6;
        }

        if (tab == Tab.HUD) {
            String editLabel = "Edit Layout";
            int editW = textRenderer.getWidth(editLabel);
            int editX = mainX + mainW - GRID_PAD - 100 - 8 - editW;
            ctx.drawText(textRenderer, editLabel, editX, py + 4, XTheme.ACCENT, false);
        }

        // search box
        int searchW = 100;
        int searchX = mainX + mainW - GRID_PAD - searchW;
        int searchColor = searchFocused ? XTheme.CARD_HOVER : XTheme.CARD_BG;
        RenderUtil.roundedRect(ctx, searchX, py, searchW, 16, 8, searchColor);
        String shown = searchQuery.isEmpty() ? "Search Mods" : searchQuery;
        int textColor2 = searchQuery.isEmpty() ? XTheme.TEXT_SECONDARY : XTheme.TEXT_PRIMARY;
        ctx.drawText(textRenderer, trimToWidth(shown, searchW - 12), searchX + 6, py + 4, textColor2, false);
    }

    private String trimToWidth(String s, int maxWidth) {
        while (s.length() > 1 && textRenderer.getWidth(s) > maxWidth) {
            s = s.substring(1);
        }
        return s;
    }

    private String tabLabel(Tab t) {
        return switch (t) {
            case ALL -> "All";
            case NEW -> "New";
            case HUD -> "HUD";
            case HYPIXEL -> "Hypixel";
            case PVP -> "PvP";
        };
    }

    private void renderGrid(DrawContext ctx, List<Module> modules, int gx, int gy, int gw, int gBottom,
                             int mouseX, int mouseY) {
        int cardW = (gw - (CARD_COLS - 1) * CARD_GAP) / CARD_COLS;
        int rows = (modules.size() + CARD_COLS - 1) / CARD_COLS;
        int contentH = rows == 0 ? 0 : rows * CARD_H + (rows - 1) * CARD_GAP;
        int viewH = Math.max(0, gBottom - gy);
        double maxScroll = Math.max(0, contentH - viewH);
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        if (scrollOffset < 0) scrollOffset = 0;

        ctx.enableScissor(gx, gy, gx + gw, gBottom);

        for (int i = 0; i < modules.size(); i++) {
            int col = i % CARD_COLS;
            int row = i / CARD_COLS;
            int cx = gx + col * (cardW + CARD_GAP);
            int cy = gy + row * (CARD_H + CARD_GAP) - (int) Math.round(scrollOffset);

            if (cy + CARD_H < gy || cy > gBottom) continue; // offscreen, skip drawing

            renderCard(ctx, modules.get(i), cx, cy, cardW, CARD_H, mouseX, mouseY);
        }

        ctx.disableScissor();

        if (modules.isEmpty()) {
            String msg = "No modules match";
            ctx.drawText(textRenderer, msg, gx + (gw - textRenderer.getWidth(msg)) / 2, gy + 20, XTheme.TEXT_SECONDARY, false);
        }
    }

    private void renderCard(DrawContext ctx, Module module, int x, int y, int w, int h, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;

        RenderUtil.card(ctx, x, y, w, h, hovered);
        if (hovered) {
            RenderUtil.rectOutline(ctx, x, y, w, h, 1, XTheme.ACCENT);
        }

        // favorite dot, top-right
        int favSize = 6;
        int favX = x + w - favSize - 6;
        int favY = y + 6;
        boolean favorited = favorites.contains(module);
        RenderUtil.roundedRect(ctx, favX, favY, favSize, favSize, 3, favorited ? XTheme.ACCENT : XTheme.TEXT_DISABLED);

        // icon, centered upper area
        int iconSize = 32;
        Identifier icon = ModuleMeta.iconFor(module);
        int iconX = x + (w - iconSize) / 2;
        int iconY = y + 10;
        if (icon != null) {
            RenderUtil.drawIcon(ctx, icon, iconX, iconY, iconSize, module.isEnabled() ? 0xFFFFFFFF : 0x99FFFFFF);
        } else {
            RenderUtil.initialBadge(ctx, textRenderer, module.getName().charAt(0), iconX, iconY, iconSize,
                    module.isEnabled() ? XTheme.ACCENT_DIM : XTheme.TOGGLE_OFF);
        }

        // name + toggle, bottom row
        int rowY = y + h - 20;
        float animT = (float) Easing.easeInOutCubic(module.getAnimationProgress(TOGGLE_ANIM_MS));

        int nameMaxWidth = w - 44;
        String name = trimToWidth(module.getName(), nameMaxWidth);
        int textColor = module.isEnabled() ? XTheme.TEXT_PRIMARY : XTheme.TEXT_SECONDARY;
        ctx.drawText(textRenderer, name, x + 8, rowY + 2, textColor, false);

        int pillW = 22, pillH = 11;
        int pillX = x + w - pillW - 8;
        int pillY = rowY - 1;
        int pillColor = module.isEnabled()
                ? blendColor(XTheme.TOGGLE_OFF, XTheme.TOGGLE_ON, module.isAnimating() ? animT : 1f)
                : blendColor(XTheme.TOGGLE_ON, XTheme.TOGGLE_OFF, module.isAnimating() ? animT : 1f);
        RenderUtil.roundedRect(ctx, pillX, pillY, pillW, pillH, pillH / 2, pillColor);

        float knobT = module.isEnabled() ? (module.isAnimating() ? animT : 1f) : (module.isAnimating() ? 1f - animT : 0f);
        int knobX = pillX + 2 + Math.round((pillW - pillH) * knobT);
        RenderUtil.roundedRect(ctx, knobX, pillY + 2, pillH - 4, pillH - 4, (pillH - 4) / 2, 0xFFFFFFFF);
    }

    private static int blendColor(int from, int to, float t) {
        int a1 = (from >> 24) & 0xFF, r1 = (from >> 16) & 0xFF, g1 = (from >> 8) & 0xFF, b1 = from & 0xFF;
        int a2 = (to >> 24) & 0xFF, r2 = (to >> 16) & 0xFF, g2 = (to >> 8) & 0xFF, b2 = to & 0xFF;
        int a = Math.round(Easing.lerp(a1, a2, t));
        int r = Math.round(Easing.lerp(r1, r2, t));
        int g = Math.round(Easing.lerp(g1, g2, t));
        int b = Math.round(Easing.lerp(b1, b2, t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------- modules

    private List<Module> visibleModules() {
        List<Module> base = switch (page) {
            case MOD_MENU -> XClientMod.getModuleManager().getModules();
            case GENERAL -> filterByCategoryOrClass(ModuleCategory.MOVEMENT, GENERAL_EXTRA);
            case CHAT -> filterByClass(CHAT_MODULES);
            case COSMETIC -> filterByCategories(ModuleCategory.RENDER, ModuleCategory.WORLD);
            case GRAPHICS -> filterByCategoryOrClass(ModuleCategory.OPTIMIZATION, Set.of());
            case SOCIAL -> filterByClass(SOCIAL_MODULES);
        };

        List<Module> result = new ArrayList<>(base);

        if (page == Page.MOD_MENU) {
            result.removeIf(m -> switch (tab) {
                case ALL -> false;
                case NEW -> !ModuleMeta.isNew(m);
                case HUD -> m.getCategory() != ModuleCategory.HUD;
                case HYPIXEL -> !ModuleMeta.isHypixel(m);
                case PVP -> !ModuleMeta.isPvp(m);
            });
        }

        if (!searchQuery.isEmpty()) {
            String q = searchQuery.toLowerCase();
            result.removeIf(m -> !m.getName().toLowerCase().contains(q)
                    && !m.getDescription().toLowerCase().contains(q));
        }

        return result;
    }

    private List<Module> filterByCategories(ModuleCategory... cats) {
        List<Module> out = new ArrayList<>();
        for (Module m : XClientMod.getModuleManager().getModules()) {
            for (ModuleCategory c : cats) {
                if (m.getCategory() == c) {
                    out.add(m);
                    break;
                }
            }
        }
        return out;
    }

    private List<Module> filterByCategoryOrClass(ModuleCategory cat, Set<Class<? extends Module>> extra) {
        List<Module> out = new ArrayList<>();
        for (Module m : XClientMod.getModuleManager().getModules()) {
            if (m.getCategory() == cat || extra.contains(m.getClass())) {
                out.add(m);
            }
        }
        return out;
    }

    private List<Module> filterByClass(Set<Class<? extends Module>> classes) {
        List<Module> out = new ArrayList<>();
        for (Module m : XClientMod.getModuleManager().getModules()) {
            if (classes.contains(m.getClass())) {
                out.add(m);
            }
        }
        return out;
    }

    // ------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int totalW = Math.min(width - 40, 700);
        int totalH = Math.min(height - 40, 420);
        int startX = (width - totalW) / 2;
        int startY = (height - totalH) / 2;
        int mainX = startX + SIDEBAR_W + PANEL_GAP;
        int mainW = totalW - SIDEBAR_W - PANEL_GAP;

        // sidebar
        if (mouseX >= startX && mouseX <= startX + SIDEBAR_W && mouseY >= startY && mouseY <= startY + totalH) {
            int cursorY = startY + 12 + 24 + 8 + 10;
            for (Page p : Page.values()) {
                if (mouseY >= cursorY && mouseY <= cursorY + 32) {
                    page = p;
                    tab = Tab.ALL;
                    scrollOffset = 0;
                    expandedSettingsModule = null;
                    searchFocused = false;
                    return true;
                }
                cursorY += 32 + 8;
            }
            return true;
        }

        int gridTop = startY + HEADER_H;

        if (page == Page.MOD_MENU) {
            int py = gridTop + (TAB_ROW_H - 16) / 2;
            int px = mainX + GRID_PAD;
            for (Tab t : Tab.values()) {
                String label = tabLabel(t);
                int w = textRenderer.getWidth(label) + 14;
                if (mouseX >= px && mouseX <= px + w && mouseY >= py && mouseY <= py + 16) {
                    tab = t;
                    scrollOffset = 0;
                    return true;
                }
                px += w + 6;
            }

            if (tab == Tab.HUD) {
                String editLabel = "Edit Layout";
                int editW = textRenderer.getWidth(editLabel);
                int editX = mainX + mainW - GRID_PAD - 100 - 8 - editW;
                if (mouseX >= editX && mouseX <= editX + editW && mouseY >= py && mouseY <= py + 16) {
                    close();
                    net.minecraft.client.MinecraftClient.getInstance().setScreen(new net.xclient.gui.hud.HudEditorScreen());
                    return true;
                }
            }

            int searchW = 100;
            int searchX = mainX + mainW - GRID_PAD - searchW;
            if (mouseX >= searchX && mouseX <= searchX + searchW && mouseY >= py && mouseY <= py + 16) {
                searchFocused = true;
                return true;
            }
            searchFocused = false;

            gridTop += TAB_ROW_H;
        }

        List<Module> visible = visibleModules();
        int gx = mainX + GRID_PAD;
        int gy = gridTop + GRID_PAD / 2;
        int gBottom = startY + totalH - GRID_PAD;
        int gw = mainW - GRID_PAD * 2;
        int cardW = (gw - (CARD_COLS - 1) * CARD_GAP) / CARD_COLS;

        if (mouseY >= gy && mouseY <= gBottom && mouseX >= gx && mouseX <= gx + gw) {
            for (int i = 0; i < visible.size(); i++) {
                int col = i % CARD_COLS;
                int row = i / CARD_COLS;
                int cx = gx + col * (cardW + CARD_GAP);
                int cy = gy + row * (CARD_H + CARD_GAP) - (int) Math.round(scrollOffset);

                if (mouseX >= cx && mouseX <= cx + cardW && mouseY >= cy && mouseY <= cy + CARD_H) {
                    Module module = visible.get(i);

                    int favSize = 6;
                    int favX = cx + cardW - favSize - 6;
                    int favY = cy + 6;
                    if (mouseX >= favX - 3 && mouseX <= favX + favSize + 3 && mouseY >= favY - 3 && mouseY <= favY + favSize + 3) {
                        if (!favorites.remove(module)) favorites.add(module);
                        return true;
                    }

                    int pillW = 22, pillH = 11;
                    int pillX = cx + cardW - pillW - 8;
                    int rowY = cy + CARD_H - 20;
                    int pillY = rowY - 1;
                    if (mouseX >= pillX - 4 && mouseY >= pillY - 2 && mouseY <= pillY + pillH + 2) {
                        module.toggle();
                    } else {
                        expandedSettingsModule = (expandedSettingsModule == module) ? null : module;
                    }
                    return true;
                }
            }
        }

        expandedSettingsModule = null;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset -= verticalAmount * 18;
        if (scrollOffset < 0) scrollOffset = 0;
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && page == Page.MOD_MENU) {
            if (searchQuery.length() < 24 && chr >= 32) {
                searchQuery += chr;
            }
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchFocused && page == Page.MOD_MENU && keyCode == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
            searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        XClientMod.getConfigManager().save(XClientMod.getModuleManager());
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
