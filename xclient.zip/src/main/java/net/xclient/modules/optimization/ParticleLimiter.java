package net.xclient.modules.optimization;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Caps the particle manager's active particle count, dropping the oldest/
 * least-visible particles first once the cap is hit. Purely a performance
 * knob layered on top of vanilla's own particle settings.
 */
public class ParticleLimiter extends Module {

    private final SliderSetting maxParticles = register(new SliderSetting("Max Particles", 500, 50, 4000, 50, true));

    public ParticleLimiter() {
        super("Particle Limiter", "Caps the number of simultaneously rendered particles.",
                ModuleCategory.OPTIMIZATION);
    }

    public int getMaxParticles() {
        return maxParticles.getValue().intValue();
    }
}
