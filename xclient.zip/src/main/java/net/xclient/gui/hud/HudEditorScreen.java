package net.xclient.gui.hud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.xclient.XClientMod;
import net.xclient.core.module.Module;
import net.xclient.gui.theme.XTheme;
import net.xclient.modules.hud.HudModule;
import net.xclient.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Standalone drag-and-drop editor for HUD widget placement. Opened from the
 * ClickGUI's HUD category (a "Edit HUD" button - wire it in ClickGUIScreen)
 * or its own keybind. Every enabled {@link HudModule} gets an outlined,
 * draggable bounding box; releasing the mouse snaps it to a 2px grid.
 */
public class HudEditorScreen extends Screen {

    private HudModule dragging;
    private float dragOffsetX, dragOffsetY;

    public HudEditorScreen() {
        super(Text.literal("Edit HUD"));
    }

    private List<HudModule> enabledHuds() {
        List<HudModule> list = new ArrayList<>();
        for (Module module : XClientMod.getModuleManager().getModules()) {
            if (module instanceof HudModule hud && hud.isEnabled()) {
                list.add(hud);
            }
        }
        return list;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x60000000);
        ctx.drawCenteredTextWithShadow(textRenderer, "Drag widgets to reposition - Escape to save & exit",
                width / 2, 12, XTheme.TEXT_PRIMARY);

        for (HudModule hud : enabledHuds()) {
            int w = Math.round(hud.getWidth() * hud.getScale());
            int h = Math.round(hud.getHeight() * hud.getScale());
            boolean hovered = mouseX >= hud.getX() && mouseX <= hud.getX() + w && mouseY >= hud.getY() && mouseY <= hud.getY() + h;

            hud.render(ctx, width, height);

            int outlineColor = hud == dragging ? XTheme.ACCENT : (hovered ? XTheme.TEXT_SECONDARY : 0x50FFFFFF);
            ctx.drawStrokedRectangle(Math.round(hud.getX()) - 2, Math.round(hud.getY()) - 2, w + 4, h + 4, outlineColor);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        for (HudModule hud : enabledHuds()) {
            int w = Math.round(hud.getWidth() * hud.getScale());
            int h = Math.round(hud.getHeight() * hud.getScale());
            if (mouseX >= hud.getX() && mouseX <= hud.getX() + w && mouseY >= hud.getY() && mouseY <= hud.getY() + h) {
                dragging = hud;
                dragOffsetX = (float) (mouseX - hud.getX());
                dragOffsetY = (float) (mouseY - hud.getY());
                hud.setDragging(true);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            float snappedX = Math.round((float) (mouseX - dragOffsetX) / 2f) * 2f;
            float snappedY = Math.round((float) (mouseY - dragOffsetY) / 2f) * 2f;
            dragging.setPosition(snappedX, snappedY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging != null) {
            dragging.setDragging(false);
            dragging = null;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        XClientMod.getConfigManager().save(XClientMod.getModuleManager());
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
