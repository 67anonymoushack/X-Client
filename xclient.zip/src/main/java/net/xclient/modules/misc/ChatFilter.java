package net.xclient.modules.misc;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Hides incoming chat lines matching user-added regex/keyword filters
 * (e.g. spam ads, join/leave floods) on the client only - never touches
 * what's actually sent or stored server-side.
 */
public class ChatFilter extends Module {

    private final List<Pattern> filters = new ArrayList<>();

    public ChatFilter() {
        super("Chat Filter", "Hides chat messages matching your keyword/regex filters.", ModuleCategory.MISC);
    }

    /** @return true if the filter was valid regex and got added, false if it was rejected. */
    public boolean addFilter(String regex) {
        try {
            filters.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
            return true;
        } catch (PatternSyntaxException e) {
            // Bad regex typed by the player - reject it instead of crashing the game.
            System.err.println("[X Client] Ignored invalid Chat Filter pattern: " + regex);
            return false;
        }
    }

    public boolean shouldHide(String message) {
        return filters.stream().anyMatch(p -> p.matcher(message).find());
    }
}
