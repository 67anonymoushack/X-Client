package net.xclient.modules.movement;

import net.xclient.core.module.Module;
import net.xclient.core.module.ModuleCategory;
import net.xclient.core.settings.SliderSetting;

/**
 * Smoothly interpolates the camera when auto-stepping up a full block,
 * instead of the vanilla instant snap - purely a camera-smoothing visual
 * effect, the actual step-up rule (block height) is unchanged.
 */
public class Step extends Module {

    private final SliderSetting smoothness = register(new SliderSetting("Smoothness", 0.2, 0.05, 0.5, 0.05));

    public Step() {
        super("Step", "Smooths the camera when auto-stepping up blocks.", ModuleCategory.MOVEMENT);
    }

    public double getSmoothness() {
        return smoothness.getValue();
    }
}
